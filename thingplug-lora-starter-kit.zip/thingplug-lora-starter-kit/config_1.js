module.exports = {

  AppEUI : 'starterkittest',                   		// Application EUI
  version : 'v1_0',                             	// Application의 version
  TPhost : 'thingplugtest.sktiot.com',      		// ThingPlug의 HOST Addresss
  TPport : '9000',                             		// ThingPlug의 HTTP PORT 번호



  responseAddress : 'http://52.78.106.100',         		// HTTP버전에서 디바이스 제어를 위한 디바이스의 물리적 주소 mga
  responsePORT : '3000',                        	// HTTP버전에서 디바이스제어를 위한 디바이스의 물리적 주소의 로컬 포트


  userID : 'userID',                            	// MQTT버전에서 Broker 접속을 위한 ID, 포털 ID 사용
  mqttClientId : 'Please Make Ramdom Value',    	// MQTT버전에서 Broker 접속을 위한 client ID


    nodeID : '01034711713',         	// Device 구분을 위한 LTID, 디바이스 고유 ID 사용
  passCode : '940707',                          	// ThingPlug에 Device등록 시 사용할 Device의 비밀번호
  uKey : 'dkVrVGFGSlMvSWFKL0dFbkNJSncwNGkzaXJMKzdBTVNhOHhtbkl3YThTTFNuenpxUjZRZFlXUk9MczBENjFOMA==',                	// Thingplug로그인 후, `마이페이지`에 있는 사용자 인증키

  appID : 'myApplication',                      	// Application의 구분을 위한 ID
  containerName:'LoRa',                         	// starter kit에서 생성하고 사용할 container 이름 (임의지정)
  DevReset : 'DevReset',                        	// starter kit에서 생성하고 사용할 제어 명령 DevReset
  RepPerChange : 'RepPerChange',                	// starter kit에서 생성하고 사용할 제어 명령 RepPerChange
  RepImmediate : 'RepImmediate',                	// starter kit에서 생성하고 사용할 제어 명령 RepImmediate
  cmdType : 'sensor_1'                          	// starter kit에서 사용할 제어 타입 (임의지정)
};
